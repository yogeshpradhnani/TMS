
<?php
session_start();
if(isset($_SESSION['email'])){
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>Create a new task </h3>
    <div class="row">
        <div class="col-md-6">
            <form action="" method="post">
                <div class="form-group">
                    <label>Select User:</label><br>
                    <select class="form-control" name="id">
                        <option>-Select-</option>
                        <?php  
                        include('../connection/connection.php');
                        $query="select uid,name from users";
                        $query_run=mysqli_query($con,$query);
                        if (mysqli_num_rows($query_run)) {
                            # code...
                            while ($row=mysqli_fetch_assoc($query_run)) {
                                # code...?>
                                <option value="<?php echo $row['uid']; ?>"><?php echo $row["name"]; ?></option><?php
                            }
                        }
                        
                        ?>
                    </select>
                </div>
                <div class="form-group" >
                    <label for="">Description</label>
                    <textarea name="description" placeholder="description"class="form-control" id="" cols="30" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label for="">Start date:</label>
                    <input type="date" name="start" class="form-control" id="">
                    </div>
                    <div class="form-group">
                    <label for="">End date:</label>
                    <input type="date" name="end" class="form-control" id="">
                </div>
           
                <br><input type="submit" value="Create Task" name="create" class="btn btn-warning">
                  
            </form>
        </div>
    </div>
</body>
</html>
<?php  } 
else{
 header('Location:admin.php');   
}?>