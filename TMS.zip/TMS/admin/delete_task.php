

<?php
session_start();
if(isset($_SESSION['email'])){
include('../connection/connection.php');
$query="delete from task where tid=$_GET[id]";
$query_run=mysqli_query($con,$query);
if ($query_run) {
    # code...
    echo "<script> alert('Task Deleted');
    window.location.href='admin_dashboard.php' </script>";
}
else {
    echo "<script> alert('An error occured');
    window.location.href='delete.php' </script>";
}
}

else{
    header('Location:admin.php');}
?>