
<?php  
session_start();
if(isset($_SESSION['email'])){

    include('../connection/connection.php');
    if (isset($_POST['edit'])) {
        # code...
        $query="update task set uid=$_POST[id],description='$_POST[description]',start='$_POST[start]',end='$_POST[end]' where tid=$_GET[id]";
        $query_run=mysqli_query($con,$query);
        if ($query_run) {
            echo "<script> alert('Task Updated');
            window.location.href='admin_dashboard.php' </script>";
        }
        else {
            echo "<script> alert('An error occured');
            window.location.href='edit_task.php' </script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>user login</title>



    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>

<body>
     <div class="row" id="header">
        <div class="col-md-12">
            <h3><i class="fa fa-solid fa-list" style="padding-right: 14px;"></i>Task Management System</h3>
        </div>
     </div>
     <div class="row">
        <div class="col-md-4 m-auto"><h3>Edit Task</h3><br>
    </div>
     </div>
     <div class="row">
     <div class="col-md-4 m-auto">
        <form action="" method="post">
            <div class="form-group">
                <input type="hidden" name="id" class="form-control" value="" required>
            </div>
            <div class="form-group">
            <label>Select User:</label><br>
            <select class="form-control" name="id" required>
                        <option>-Select-</option>
                        <?php  
                        include('../connection/connection.php');
                        $query="select * from task where tid=$_GET[id]";
                        $query1="select uid,name from users";
                        $query_run1=mysqli_query($con,$query1);
                        $query_run=mysqli_query($con,$query);
                        if (mysqli_num_rows($query_run1)) {
                            # code...
                            while ($row1=mysqli_fetch_assoc($query_run1)) {
                                # code...?>
                                <option value="<?php echo $row1['uid']; ?>"><?php echo $row1["name"]; ?></option><?php
                            }
                        }
                        
                

                        
                        
                        ?>
                    </select>

            </div>
            <?php while ($row2=mysqli_fetch_assoc($query_run)) {

# code...

?>

            <div class="form-group" >
                    <label for="">Description</label>
                    <textarea name="description" class="form-control" id="" cols="30" rows="3" required value=""><?php echo $row2['description']; ?></textarea>
                </div>
                <div class="form-group">
                    <label for="">Start date:</label>
                    <input type="date" name="start" class="form-control" id="" value="<?php echo $row2['start'];?>" required>
                    </div>
                    <div class="form-group">
                    <label for="">End date:</label>
                    <input type="date" name="end" class="form-control" id="" value="<?php echo $row2['end']; ?>" required>
                </div>
           
                <br><input type="submit" value="Update Task" name="edit" class="btn btn-warning">
        </form> <?php } ?>
</div>

     </div>
    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>

</html>
<?php
}

else{
    header('Location:admin.php');}   ?>