<?php
session_start();
if(isset($_SESSION['email'])){

include('../connection/connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<body>
   <center> <h3>All Assigned Task</h3><center><br>
   <table class="table" style="width: 70vw;">
    <tr>
        <th>S.no</th>
        <th>User Id</th>
        <th>Name</th>
        <th>Subject</th>
        <th>Message</th>
   
        <th>Status</th>
        <th>Action</th>
    </tr>
    <?php
    $sno=1;
    $query="select * from leaves";
    
    $query_run=mysqli_query($con,$query);
    while ($row=mysqli_fetch_assoc($query_run)) {
        # code...
        ?>
        <tr>
        <td><?php echo  $sno ?></td>
        <td><?php echo  $row['uid'];?></td>
        <?php $query1="select name from users where uid=$row[uid]";
        $query_run1=mysqli_query($con,$query1);
        while ($row1=mysqli_fetch_assoc($query_run1)) {
           ?>  <td><?php echo  $row1['name'];?></td><?php
        }?>
        
        <td><?php echo $row['subject'];?></td>
        <td><?php echo  $row['message'];?></td>
     
        <td><?php echo  $row['status'];?></td>
        <td><a href="approve.php?id=<?php echo $row['lid'] ?>">Approved</a> | <a href="reject.php?id=<?php echo $row['lid'] ?>">Rejected</a></td>
        
    </tr>
    <?php
    $sno=$sno+1;
    }
?>
   </table>
</body>
</html>
<?php
}

else{
    header('Location:admin.php');}   ?>