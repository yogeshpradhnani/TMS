<?php
session_start();
if(isset($_SESSION['email'])){

include('../connection/connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<body>
   <center> <h3>All Assigned Task</h3><center><br>
   <table class="table" style="width: 70vw;">
    <tr>
        <th>S.no</th>
        <th>Task Id</th>
        <th>Description</th>
        <th>Start date</th>
        <th>End date</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
    <?php
    $sno=1;
    $query="select * from task";
    $query_run=mysqli_query($con,$query);
    while ($row=mysqli_fetch_assoc($query_run)) {
        # code...
        ?>
        <tr>
        <td><?php echo  $sno;?></td>
        <td><?php echo  $row['tid'];?></td>
        <td><?php echo $row['description'];?></td>
        <td><?php echo  $row['start'];?></td>
        <td><?php echo  $row['end'];?></td>
        <td><?php echo  $row['status'];?></td>
        <td><a href="edit_task.php?id=<?php echo $row['tid'] ?>">Edit</a> | <a href="delete_task.php?id=<?php echo $row['tid'] ?>">Delete</a></td>
        
    </tr>
    <?php
    $sno=$sno+1;
    }
?>
   </table>
</body>
</html>
<?php
}

else{
    header('Location:admin.php');}   ?>