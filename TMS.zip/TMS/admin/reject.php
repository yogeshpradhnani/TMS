<?php  
session_start();
if(isset($_SESSION['email'])){

    include('../connection/connection.php');

        # code...
        $query="update leaves set status='Rejected' where lid=$_GET[id]";
        $query_run=mysqli_query($con,$query);
        if ($query_run) {
            echo "<script> alert('Leave Rejected');
            window.location.href='admin_dashboard.php' </script>";
        }
        else {
            echo "<script> alert('An error occured');
            window.location.href='edit_task.php' </script>";
    }


  
}

else{
    header('Location:admin.php');}   ?>