<?php 
session_start();
if(isset($_SESSION['email'])){

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">




    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <div class="row" >
    
            <h3>Leave Apply </h3>
            <div class="col-md-6">
            <form action="" method="post">
            <div class="form-group" style="padding-top: 3px;">
          <input type="text" class="form-control" name="subject"> </div>
                           
                <div class="form-group" style="padding-top: 3px;">
                <textarea name="message" placeholder="message"class="form-control" id="" cols="30" rows="3" required></textarea></div>
             
                <div class="form-group" style="padding-top: 3px;">
                   <center> <input type="submit" value="Apply Leave" name="apply" class="btn btn-warning"></center>
                </div>
            </form>
           
        </div> 
        
    </div>
    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>

</html>
<?php  } 
else{
 header('Location:user_login.php');   
}?>