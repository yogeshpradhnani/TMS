<?php  
session_start();
if(isset($_SESSION['email'])){

    include('connection/connection.php');
    if (isset($_POST['edit'])) {
        # code...
        $query="update task set status='$_POST[status]' where tid=$_GET[id]";
        $query_run=mysqli_query($con,$query);
        if ($query_run) {
            echo "<script> alert('Task Updated');
            window.location.href='user_dashboard.php' </script>";
        }
        else {
            echo "<script> alert('An error occured');
            window.location.href='edit_task.php' </script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>user login</title>



    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
     <div class="row" id="header">
        <div class="col-md-12">
            <h3><i class="fa fa-solid fa-list" style="padding-right: 14px;"></i>Task Management System</h3>
        </div>
     </div>
     <div class="row">
        <div class="col-md-4 m-auto"><h3>Edit Task</h3><br>
    </div>
     </div>
     <div class="row">
     <div class="col-md-4 m-auto">
        <form action="" method="post">
            <div class="form-group">
                <input type="hidden" name="id" class="form-control" value="" required>
            </div>
            
                  
                        
                        
                


            <div class="form-group" >
                    <label for="">Update Status</label>
                    <select class="form-control" name="status">
                        <?php $query1="select status from task where tid=$_GET[id]";
                        $query_run1=mysqli_query($con,$query1);
                        if (mysqli_num_rows($query_run1)) {
                            # code...
                            while ($row1=mysqli_fetch_assoc($query_run1)) {
                                # code...
                                if($row1['status']=="In process")
                                {
                                    ?><option><?php echo $row1['status'] ?></option>
                                    <option>Completed</option>
                               <?php }
                               else if($row1['status']=="Completed")
                               {
                                ?>
                                <option>Completed</option> <?php
                               }
                               else
                               {
                                 ?>
                        <option>In process</option>
                        <option>Completed</option><?php
                               }
                               
                               
                            }
                        }
                         ?>

                </div>
                
                <br><br><input type="submit" value="Update Task" name="edit" class="btn btn-warning">
        </form> 
</div>

     </div>
    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>

</html>
<?php  } 
else{
 header('Location:user_login.php');   
}?>