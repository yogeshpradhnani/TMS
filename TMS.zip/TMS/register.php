<?php
include('connection/connection.php');
if (isset($_POST['Register'])) {
    $query="insert into users values(null,'$_POST[name]','$_POST[email]','$_POST[pass]',$_POST[mobile])";
    $query_run=mysqli_query($con,$query);
    if ($query_run) {
        # code...
        echo "<script> alert('registered successfully');
        window.location.href='index.html' </script>";
    }
    else {
        echo "<script> alert('An error occured');
        window.location.href='register.php' </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>user Registration</title>



    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <div class="row">
        <div class="col-md-3 m-auto" id="register_home_page">
            <center><h3 style="background-color: grey; padding: 5px; width: 15vw; font-size: 15px;">User Registration </h3></center>
            <form action="" method="post">
            <div class="form-group" style="padding-top: 2px;">
                    <input type="text" name="name" class="form-control" placeholder="Enter Name" required></div>
                           
                <div class="form-group" style="padding-top: 2px;">
                    <input type="email" name="email" class="form-control" placeholder="Enter email" required></div>
                    <div class="form-group" style="padding-top: 2px;">
                    <input type="password" name="pass" class="form-control" placeholder="Enter password" required>
                </div>
                <div class="form-group" style="padding-top: 2px;">
                    <input type="text" name="mobile" class="form-control" placeholder="Enter Mobile no." required></div>
                <div class="form-group" style="padding-top: 6px;">
                   <center> <input type="submit" value="Register" name="Register" class="btn btn-warning"></center>
                </div>
            </form>
            <br>
            <center><a href="index.html" class="btn btn-danger">Go To Home</a></center>
        </div> 
        
    </div>
    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>

</html>