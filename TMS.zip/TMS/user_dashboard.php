<?php
session_start();
if(isset($_SESSION['email'])){


include('connection/connection.php');
if (isset($_POST['apply'])) {
    $query="insert into leaves values(null,$_SESSION[uid],'$_POST[subject]','$_POST[message]','pending')";
    $query_run=mysqli_query($con,$query);
    if ($query_run) {
        # code...
        echo "<script> alert('registered successfully');
        window.location.href='user_dashboard.php' </script>";
    }
    else {
        echo "<script> alert('An error occured');
        window.location.href='user_dashboard.php' </script>";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>user Dashboard</title>



    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <div class="row" id="header">
        <div class="col-md-12">
            <div class="col-md-4" style="display: inline-block;">
                <h4>Task Management System</h4>
            </div>
            <div class="col-md-6"  style="display: inline-block;text-align: right;">
                <b>Email:</b><?php echo $_SESSION['email']; ?>
                <span style="padding-left: 25px;"><b>Name:</b><?php echo $_SESSION['name']; ?></span>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-2" id="left_sidebar">
            <table class="table">
                <tr>
                    <td style="text-align: center;"><a href="user_dashboard.php" type="button" id="logout_link">Dashboard</a></td>
                </tr>
                <tr>
                    <td style="text-align: center;"><a id="update_task" type="button">Task</a></td>
                </tr>
                <tr>
                    <td style="text-align: center;"><a id="apply_leave" type="button">Apply Leave</a></td>
                </tr>
                <tr>
                    <td style="text-align: center;"><a id="view_leave" type="button">Leave Status</a></td>
                </tr>
                <tr>
                    <td style="text-align: center;"><a href="logout.php" type="button" id="logout_link">Logout</a></td>
                </tr>
            </table>

        </div>
        <div class="col-md-10" id="right-sidebar" >
            <h4>Instruction for employees</h4>
            <ul>
                <li>
                    All the employee should mark their attendence daily
                </li>
                <li>
                    Everyone must complete the task assigned to them
                </li>
                <li>
                    kindly maintain decorum of the office
                </li>
                <li>
                    keep office and your area neat and clean
                </li>
            </ul>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $("#apply_leave").click(function () {
                $('#right-sidebar').load("apply_leave.php");
            });
            
        });
        $(document).ready(function () {
            $("#update_task").click(function () {
                $('#right-sidebar').load("update_task.php");
            });
            
        });
        $(document).ready(function () {
            $("#view_leave").click(function () {
                $('#right-sidebar').load("view_leave.php");
            });
            
        });
    </script>
</body>

</html>
<?php  } 
else{
 header('Location:user_login.php');   
}?>